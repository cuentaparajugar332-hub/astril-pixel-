import { streamText } from 'ai'

export async function POST(req: Request) {
  const { messages, apiKey } = await req.json()

  const modelMessages = messages.map((m: { role: string; content: string }) => ({
    role: m.role as 'user' | 'assistant',
    content: m.content,
  }))

  const result = streamText({
    model: 'openai/gpt-4o-mini',
    system: `Eres PIXEL, el asistente experto en pixel art de ASTRILIA IA. 
Ayudas a artistas y desarrolladores a crear, mejorar y entender el pixel art.

Tus especialidades:
- Tecnicas de pixel art (dithering, anti-aliasing manual, outlines, animacion)
- Paletas de colores para pixel art (limitadas, retro, PICO-8, GameBoy, etc.)
- Sprites, tiles y tilesets para videojuegos
- Isometrico, top-down y side-scrollers
- Prompts optimizados para generar pixel art con IA
- Uso de ASTRILIA IA: el editor, las herramientas y las API Keys

Responde siempre en español, de forma concisa y practica.
Cuando des ejemplos de prompts para el generador de IA, formatealos entre comillas y con el prefijo "Prompt:".
`,
    messages: modelMessages,
    maxOutputTokens: 800,
    ...(apiKey ? { headers: { 'X-Custom-API-Key': apiKey } } : {}),
  })

  return result.toUIMessageStreamResponse()
}
