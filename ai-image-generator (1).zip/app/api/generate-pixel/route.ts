import { generateText, Output } from 'ai'
import { z } from 'zod'

export const maxDuration = 60

interface PixelGridRequest {
  prompt: string
  gridSize: number
  palette: string[]
  apiKey?: string
}

export async function POST(req: Request) {
  try {
    const { prompt, gridSize, palette, apiKey } = (await req.json()) as PixelGridRequest

    const paletteStr = palette.slice(0, 16).join(', ')
    const totalPixels = gridSize * gridSize

    const systemPrompt = `Eres un artista experto en pixel art 2D. Tu tarea es generar datos de pixeles para una imagen de pixel art.

INSTRUCCIONES CRITICAS:
- Genera exactamente ${totalPixels} colores en el array "pixels" (${gridSize} filas x ${gridSize} columnas).
- Cada color debe ser un codigo hex valido (#RRGGBB) o "transparent" para pixeles vacios.
- Usa SOLO colores de esta paleta o variaciones muy cercanas: ${paletteStr}
- El orden es: fila 0 de izquierda a derecha, luego fila 1, etc.
- Para un sujeto centrado: usa "transparent" para el fondo y los colores de la paleta para el sujeto.
- Crea arte reconocible y detallado para la resolucion ${gridSize}x${gridSize}.`

    const { experimental_output } = await generateText({
      model: 'openai/gpt-4o-mini',
      system: systemPrompt,
      prompt: `Crea pixel art de: "${prompt}". Genera exactamente ${totalPixels} valores de color en formato hex o "transparent".`,
      experimental_output: Output.object({
        schema: z.object({
          pixels: z
            .array(z.string())
            .length(totalPixels)
            .describe(`Array de exactamente ${totalPixels} colores hex (#RRGGBB) o "transparent"`),
          description: z.string().describe('Descripcion breve del pixel art generado'),
        }),
      }),
      ...(apiKey ? { headers: { Authorization: `Bearer ${apiKey}` } } : {}),
    })

    if (!experimental_output?.pixels || experimental_output.pixels.length !== totalPixels) {
      return Response.json({ error: 'La IA no genero los pixeles correctamente. Intenta de nuevo.' }, { status: 422 })
    }

    return Response.json({
      pixels: experimental_output.pixels,
      description: experimental_output.description,
    })
  } catch (error) {
    console.error('[generate-pixel] Error:', error)
    return Response.json(
      { error: 'Error al generar el pixel art. Por favor intenta de nuevo.' },
      { status: 500 }
    )
  }
}
