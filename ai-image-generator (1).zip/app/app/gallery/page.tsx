'use client'

import { useEffect, useState, useCallback } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Pencil, Trash2, Download, Images } from 'lucide-react'

interface GalleryItem {
  id: string
  pixels: string[]
  gridSize: number
  prompt: string
  createdAt: number
}

function renderThumbnail(item: GalleryItem): string {
  const size = 128
  const canvas = document.createElement('canvas')
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext('2d')
  if (!ctx) return ''
  const cell = size / item.gridSize
  ctx.fillStyle = '#10102a'
  ctx.fillRect(0, 0, size, size)
  for (let i = 0; i < item.gridSize * item.gridSize; i++) {
    const c = item.pixels[i]
    if (c && c !== 'transparent') {
      ctx.fillStyle = c
      ctx.fillRect((i % item.gridSize) * cell, Math.floor(i / item.gridSize) * cell, cell, cell)
    }
  }
  return canvas.toDataURL('image/png')
}

function PixelThumbnail({ item }: { item: GalleryItem }) {
  const [src, setSrc] = useState<string>('')

  useEffect(() => {
    setSrc(renderThumbnail(item))
  }, [item])

  if (!src) {
    return <div className="w-full aspect-square bg-card animate-pulse rounded" />
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt={item.prompt}
      className="w-full aspect-square pixel-canvas rounded border border-border"
      style={{ imageRendering: 'pixelated' }}
    />
  )
}

export default function GalleryPage() {
  const [items, setItems] = useState<GalleryItem[]>([])

  useEffect(() => {
    const stored = localStorage.getItem('astrilia_gallery')
    if (stored) setItems(JSON.parse(stored))
  }, [])

  const handleDelete = useCallback((id: string) => {
    setItems((prev) => {
      const next = prev.filter((i) => i.id !== id)
      localStorage.setItem('astrilia_gallery', JSON.stringify(next))
      return next
    })
  }, [])

  const handleDownload = useCallback((item: GalleryItem) => {
    const src = renderThumbnail(item)
    const a = document.createElement('a')
    a.download = `astrilia-${item.id}.png`
    a.href = src
    a.click()
  }, [])

  const handleEdit = useCallback((item: GalleryItem) => {
    localStorage.setItem('astrilia_editor_load', JSON.stringify(item))
    window.location.href = '/app/editor'
  }, [])

  if (items.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center gap-4 bg-background">
        <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
          <Images className="w-7 h-7 text-primary" />
        </div>
        <div className="text-center">
          <h2 className="text-sm font-semibold text-foreground mb-1">Galeria vacia</h2>
          <p className="text-xs text-muted-foreground max-w-xs leading-relaxed">
            Guarda tus creaciones desde el editor para verlas aqui.
          </p>
        </div>
        <Link
          href="/app/editor"
          className="inline-flex items-center justify-center bg-primary text-primary-foreground hover:bg-primary/90 text-xs h-8 px-3 rounded-lg font-medium transition-colors"
        >
          Ir al editor
        </Link>
      </div>
    )
  }

  return (
    <div className="h-full overflow-y-auto bg-background">
      <div className="max-w-6xl mx-auto p-6">
        {/* Stats bar */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-[10px] border-border text-muted-foreground">
              {items.length} {items.length === 1 ? 'creacion' : 'creaciones'}
            </Badge>
          </div>
          <Link
            href="/app/editor"
            className="inline-flex items-center justify-center bg-primary text-primary-foreground hover:bg-primary/90 h-7 px-2.5 text-xs rounded-lg font-medium transition-colors"
          >
            Nuevo
          </Link>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {items.map((item) => (
            <div
              key={item.id}
              className="group flex flex-col gap-2"
            >
              <div className="relative overflow-hidden rounded-lg border border-border hover:border-primary/40 transition-colors">
                <PixelThumbnail item={item} />
                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={() => handleEdit(item)}
                    className="w-8 h-8 rounded-lg bg-card border border-border flex items-center justify-center hover:border-primary hover:text-primary transition-colors"
                    title="Editar"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDownload(item)}
                    className="w-8 h-8 rounded-lg bg-card border border-border flex items-center justify-center hover:border-primary hover:text-primary transition-colors"
                    title="Descargar"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="w-8 h-8 rounded-lg bg-card border border-border flex items-center justify-center hover:border-destructive hover:text-destructive transition-colors"
                    title="Eliminar"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <div className="px-0.5">
                <p className="text-[11px] text-foreground font-medium truncate">{item.prompt}</p>
                <p className="text-[10px] text-muted-foreground">
                  {item.gridSize}x{item.gridSize} · {new Date(item.createdAt).toLocaleDateString('es', { day: '2-digit', month: 'short' })}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
