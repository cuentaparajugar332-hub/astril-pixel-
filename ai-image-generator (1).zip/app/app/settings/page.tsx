'use client'

import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { useRouter } from 'next/navigation'
import { LogOut, User, Shield } from 'lucide-react'

export default function SettingsPage() {
  const { user, logout } = useAuth()
  const router = useRouter()

  const handleLogout = () => {
    logout()
    router.push('/login')
  }

  return (
    <div className="h-full overflow-y-auto bg-background">
      <div className="max-w-2xl mx-auto px-6 py-8 flex flex-col gap-6">

        {/* Profile */}
        <div className="rounded-lg border border-border bg-card p-5 flex flex-col gap-4">
          <div className="flex items-center gap-2 mb-1">
            <User className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-semibold text-foreground">Perfil</h2>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center shrink-0">
              <span className="text-base font-bold text-primary">{user?.avatar}</span>
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">{user?.name}</p>
              <p className="text-xs text-muted-foreground">{user?.email}</p>
            </div>
          </div>
        </div>

        {/* Security */}
        <div className="rounded-lg border border-border bg-card p-5 flex flex-col gap-3">
          <div className="flex items-center gap-2 mb-1">
            <Shield className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-semibold text-foreground">Seguridad</h2>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Tu cuenta se gestiona localmente en este navegador. Los datos se guardan en localStorage
            y son privados en este dispositivo.
          </p>
        </div>

        {/* Danger zone */}
        <div className="rounded-lg border border-destructive/30 bg-card p-5 flex flex-col gap-3">
          <h2 className="text-sm font-semibold text-destructive">Zona de peligro</h2>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Cerrar sesion eliminara tu sesion activa. Tus creaciones y configuracion permanecen
            guardadas en este navegador.
          </p>
          <Button
            onClick={handleLogout}
            variant="outline"
            size="sm"
            className="w-fit h-8 text-xs gap-1.5 border-destructive/40 text-destructive hover:bg-destructive/10"
          >
            <LogOut className="w-3.5 h-3.5" />
            Cerrar sesion
          </Button>
        </div>
      </div>
    </div>
  )
}
