'use client'

import { useState, useCallback, useEffect } from 'react'
import { PixelCanvas } from '@/components/pixel-canvas'
import { PixelToolbar, PALETTE_PRESETS, type PaletteKey } from '@/components/pixel-toolbar'
import { AIPanel } from '@/components/ai-panel'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Download,
  Save,
  Sparkles,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react'

const MAX_HISTORY = 40

function createEmpty(size: number) {
  return Array(size * size).fill('transparent')
}

export default function EditorPage() {
  const [gridSize, setGridSize] = useState(16)
  const [pixels, setPixels] = useState<string[]>(() => createEmpty(16))
  const [history, setHistory] = useState<string[][]>([])
  const [tool, setTool] = useState<'draw' | 'erase' | 'fill'>('draw')
  const [activeColor, setActiveColor] = useState('#00cfff')
  const [palette, setPalette] = useState<PaletteKey>('retro')
  const [label, setLabel] = useState('Sin titulo')
  const [saveMsg, setSaveMsg] = useState<string | null>(null)
  const [aiOpen, setAiOpen] = useState(false)

  // Load from gallery if redirected
  useEffect(() => {
    const stored = localStorage.getItem('astrilia_editor_load')
    if (stored) {
      try {
        const item = JSON.parse(stored)
        setGridSize(item.gridSize)
        setPixels(item.pixels)
        setLabel(item.prompt)
        setHistory([])
      } catch {}
      localStorage.removeItem('astrilia_editor_load')
    }
  }, [])

  const pushHistory = useCallback((prev: string[]) => {
    setHistory((h) => {
      const next = [...h, prev]
      return next.length > MAX_HISTORY ? next.slice(-MAX_HISTORY) : next
    })
  }, [])

  const handlePixelsChange = useCallback(
    (newPixels: string[]) => {
      setPixels((prev) => {
        pushHistory(prev)
        return newPixels
      })
    },
    [pushHistory]
  )

  const handleUndo = () => {
    setHistory((h) => {
      if (h.length === 0) return h
      const prev = h[h.length - 1]
      setPixels(prev)
      return h.slice(0, -1)
    })
  }

  const handleClear = () => {
    pushHistory(pixels)
    setPixels(createEmpty(gridSize))
  }

  const handleGridSizeChange = (size: number) => {
    setGridSize(size)
    setPixels(createEmpty(size))
    setHistory([])
  }

  const handleAIGenerate = (newPixels: string[], description: string) => {
    pushHistory(pixels)
    setPixels(newPixels)
    setLabel(description || 'Generado por IA')
    setAiOpen(false)
  }

  const downloadPNG = () => {
    const size = 512
    const canvas = document.createElement('canvas')
    canvas.width = size
    canvas.height = size
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const cell = size / gridSize
    for (let i = 0; i < gridSize * gridSize; i++) {
      const c = pixels[i]
      if (c && c !== 'transparent') {
        ctx.fillStyle = c
        ctx.fillRect((i % gridSize) * cell, Math.floor(i / gridSize) * cell, cell, cell)
      }
    }
    const a = document.createElement('a')
    a.download = `astrilia-${Date.now()}.png`
    a.href = canvas.toDataURL('image/png')
    a.click()
  }

  const handleSave = () => {
    const item = {
      id: `${Date.now()}`,
      pixels: [...pixels],
      gridSize,
      prompt: label,
      createdAt: Date.now(),
    }
    const existing = JSON.parse(localStorage.getItem('astrilia_gallery') || '[]')
    localStorage.setItem('astrilia_gallery', JSON.stringify([item, ...existing].slice(0, 100)))
    setSaveMsg('Guardado')
    setTimeout(() => setSaveMsg(null), 2000)
  }

  const hasContent = pixels.some((p) => p && p !== 'transparent')
  const currentPalette = PALETTE_PRESETS[palette] as unknown as string[]

  return (
    <div className="h-full flex overflow-hidden bg-background">
      {/* Left toolbar */}
      <aside className="w-64 border-r border-border flex flex-col overflow-y-auto shrink-0 bg-[#0c0c20]">
        <div className="px-4 pt-4 pb-2">
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            Herramientas
          </p>
          <PixelToolbar
            tool={tool}
            onToolChange={setTool}
            activeColor={activeColor}
            onColorChange={setActiveColor}
            gridSize={gridSize}
            onGridSizeChange={handleGridSizeChange}
            onClear={handleClear}
            onUndo={handleUndo}
            canUndo={history.length > 0}
            palette={palette}
            onPaletteChange={setPalette}
          />
        </div>
      </aside>

      {/* Canvas area */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Canvas toolbar */}
        <div className="h-11 border-b border-border flex items-center gap-3 px-4 shrink-0 bg-[#0c0c20]/60">
          <span className="text-xs text-muted-foreground truncate max-w-[200px]">{label}</span>
          <Badge variant="outline" className="text-[10px] border-border text-muted-foreground h-5 px-1.5">
            {gridSize}x{gridSize}
          </Badge>
          <div className="flex-1" />
          {saveMsg && (
            <span className="text-xs text-primary animate-in fade-in">{saveMsg}</span>
          )}
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setAiOpen(!aiOpen)}
            className="h-7 text-xs gap-1.5 text-primary border border-primary/30 hover:bg-primary/10"
          >
            <Sparkles className="w-3.5 h-3.5" />
            IA
            {aiOpen ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleSave}
            disabled={!hasContent}
            className="h-7 text-xs gap-1.5 hover:bg-secondary"
          >
            <Save className="w-3.5 h-3.5" />
            Guardar
          </Button>
          <Button
            size="sm"
            onClick={downloadPNG}
            disabled={!hasContent}
            className="h-7 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Download className="w-3.5 h-3.5" />
            PNG
          </Button>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Canvas */}
          <div className="flex-1 flex items-center justify-center p-6 canvas-bg overflow-auto">
            <div className="relative">
              <PixelCanvas
                pixels={pixels}
                gridSize={gridSize}
                activeColor={activeColor}
                tool={tool}
                onPixelsChange={handlePixelsChange}
              />
            </div>
          </div>

          {/* AI panel — right slide */}
          {aiOpen && (
            <>
              <Separator orientation="vertical" className="bg-border" />
              <aside className="w-72 shrink-0 overflow-y-auto bg-[#0c0c20] border-l border-border">
                <div className="px-4 pt-4 pb-4">
                  <div className="flex items-center gap-2 mb-4">
                    <Sparkles className="w-3.5 h-3.5 text-primary" />
                    <p className="text-xs font-semibold text-foreground">Generar con IA</p>
                  </div>
                  <AIPanel
                    gridSize={gridSize}
                    palette={currentPalette}
                    onPixelsGenerated={handleAIGenerate}
                  />
                </div>
              </aside>
            </>
          )}
        </div>
      </main>
    </div>
  )
}
