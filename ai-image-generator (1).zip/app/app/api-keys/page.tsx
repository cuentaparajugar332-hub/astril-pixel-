'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Eye, EyeOff, Save, Trash2, Key, Check } from 'lucide-react'

export default function ApiKeysPage() {
  const [openaiKey, setOpenaiKey] = useState('')
  const [showKey, setShowKey] = useState(false)
  const [saved, setSaved] = useState(false)
  const [hasKey, setHasKey] = useState(false)

  useEffect(() => {
    const stored = localStorage.getItem('astrilia_openai_key')
    if (stored) {
      setOpenaiKey(stored)
      setHasKey(true)
    }
  }, [])

  const handleSave = () => {
    if (openaiKey.trim()) {
      localStorage.setItem('astrilia_openai_key', openaiKey.trim())
      setHasKey(true)
      setSaved(true)
      setTimeout(() => setSaved(false), 2500)
    }
  }

  const handleDelete = () => {
    localStorage.removeItem('astrilia_openai_key')
    setOpenaiKey('')
    setHasKey(false)
  }

  const masked = openaiKey ? `${openaiKey.slice(0, 8)}${'•'.repeat(Math.max(0, openaiKey.length - 8))}` : ''

  return (
    <div className="h-full overflow-y-auto bg-background">
      <div className="max-w-2xl mx-auto px-6 py-8 flex flex-col gap-6">

        {/* Header info */}
        <div className="rounded-lg border border-border bg-card p-5 flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-semibold text-foreground">Tu API Key de OpenAI</h2>
            {hasKey && (
              <Badge className="text-[10px] bg-primary/15 text-primary border-primary/30 h-5">
                Activa
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Conecta tu propia clave de OpenAI para usar el generador de pixel art y el Bot IA
            con tu cuota personal. Tu clave se guarda unicamente en tu navegador y nunca
            se envia a nuestros servidores.
          </p>
          <div className="text-xs text-muted-foreground bg-secondary/40 border border-border rounded-md px-3 py-2">
            Consigue tu API Key en{' '}
            <a
              href="https://platform.openai.com/api-keys"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              platform.openai.com/api-keys
            </a>
          </div>
        </div>

        {/* Input card */}
        <div className="rounded-lg border border-border bg-card p-5 flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="api-key" className="text-xs text-muted-foreground">
              OpenAI API Key
            </Label>
            <div className="relative">
              <Input
                id="api-key"
                type={showKey ? 'text' : 'password'}
                placeholder="sk-proj-..."
                value={showKey ? openaiKey : (openaiKey ? masked : '')}
                onChange={(e) => setOpenaiKey(e.target.value)}
                className="font-mono text-xs h-9 bg-background border-border text-foreground placeholder:text-muted-foreground pr-10 focus-visible:ring-primary/30 focus-visible:border-primary/60"
                spellCheck={false}
                autoComplete="off"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                tabIndex={-1}
              >
                {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
            <p className="text-[10px] text-muted-foreground">
              Formato: sk-proj-... o sk-... · Guardada localmente en tu navegador
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              onClick={handleSave}
              disabled={!openaiKey.trim() || saved}
              size="sm"
              className="h-8 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {saved ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  Guardada
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  Guardar clave
                </>
              )}
            </Button>
            {hasKey && (
              <Button
                onClick={handleDelete}
                variant="outline"
                size="sm"
                className="h-8 text-xs gap-1.5 border-destructive/40 text-destructive hover:bg-destructive/10"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Eliminar
              </Button>
            )}
          </div>
        </div>

        {/* How it works */}
        <div className="rounded-lg border border-border bg-card p-5 flex flex-col gap-3">
          <p className="text-xs font-semibold text-foreground uppercase tracking-wider">Como funciona</p>
          <ul className="flex flex-col gap-2">
            {[
              'Tu API Key se guarda en localStorage de tu navegador, nunca en nuestros servidores.',
              'Se usa automaticamente en el generador de pixel art y el Bot IA cuando esta presente.',
              'Sin API Key, ASTRILIA usa su propia cuota compartida con velocidad reducida.',
              'Puedes borrarla en cualquier momento desde esta pagina.',
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                <span className="w-4 h-4 rounded-full bg-primary/15 text-primary text-[9px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                  {i + 1}
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
