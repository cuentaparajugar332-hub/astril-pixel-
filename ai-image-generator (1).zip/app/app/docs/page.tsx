'use client'

import { useState } from 'react'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { ChevronRight } from 'lucide-react'

const SECTIONS = [
  {
    id: 'intro',
    label: 'Introduccion',
    content: (
      <div className="flex flex-col gap-4">
        <h2 className="text-lg font-semibold text-foreground">Bienvenido a ASTRILIA IA</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">
          ASTRILIA IA es un editor de pixel art 2D potenciado por inteligencia artificial.
          Puedes dibujar manualmente, generar sprites con IA usando texto en espanol, guardar tu galeria
          y descargar tus creaciones como PNG.
        </p>
        <div className="grid grid-cols-2 gap-3">
          {[
            { title: 'Editor', desc: 'Dibuja pixel a pixel con herramientas de dibujo, borrado y relleno.' },
            { title: 'Bot IA', desc: 'Habla con PIXEL, el asistente especializado en pixel art.' },
            { title: 'Galeria', desc: 'Guarda y gestiona todas tus creaciones.' },
            { title: 'API Keys', desc: 'Conecta tu propia clave de OpenAI para mayor velocidad.' },
          ].map((item) => (
            <div key={item.title} className="rounded-lg border border-border bg-card p-4">
              <p className="text-sm font-medium text-foreground mb-1">{item.title}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 'editor',
    label: 'Editor',
    content: (
      <div className="flex flex-col gap-4">
        <h2 className="text-lg font-semibold text-foreground">Editor de Pixel Art</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">
          El editor es el corazon de ASTRILIA. Cuenta con un lienzo configurable y un panel de herramientas completo.
        </p>
        <div className="flex flex-col gap-3">
          {[
            { label: 'Herramientas', items: ['Dibujar — pinta pixeles individuales arrastrando', 'Borrar — elimina el color del pixel', 'Rellenar — rellena zonas contiguas del mismo color (flood fill)'] },
            { label: 'Tamanos de lienzo', items: ['8x8 — ideal para iconos', '16x16 — sprites clasicos', '32x32 — personajes detallados', '48x48 — escenas complejas'] },
            { label: 'Paletas', items: ['Retro — 20 colores clasicos', 'GameBoy — 16 colores de consola', 'Neon — colores vivos y oscuros'] },
            { label: 'Acciones', items: ['Deshacer — Ctrl+Z o boton (hasta 40 pasos)', 'Limpiar — borra todo el lienzo', 'Guardar — guarda en tu galeria local', 'Descargar PNG — exporta a 512x512 px'] },
          ].map((group) => (
            <div key={group.label} className="rounded-lg border border-border bg-card p-4">
              <p className="text-xs font-semibold text-foreground mb-2 uppercase tracking-wider">{group.label}</p>
              <ul className="flex flex-col gap-1">
                {group.items.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-xs text-muted-foreground">
                    <ChevronRight className="w-3 h-3 mt-0.5 text-primary shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 'ia',
    label: 'Generador IA',
    content: (
      <div className="flex flex-col gap-4">
        <h2 className="text-lg font-semibold text-foreground">Generador de IA</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">
          El generador convierte tu descripcion en texto a pixels usando un modelo de lenguaje.
          Haz click en el boton IA del editor para abrir el panel.
        </p>
        <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
          <p className="text-xs font-semibold text-primary mb-2">Como escribir buenos prompts</p>
          <ul className="flex flex-col gap-1.5">
            {[
              'Se especifico: "dragon rojo pequeno de lado" es mejor que "dragon"',
              'Menciona el estilo: "estilo SNES", "8-bit clasico", "gameboy verde"',
              'Indica la vista: "vista lateral", "vista de frente", "isometrico"',
              'Especifica colores: "paleta oscura con ojos amarillos"',
            ].map((tip) => (
              <li key={tip} className="flex items-start gap-2 text-xs text-muted-foreground">
                <ChevronRight className="w-3 h-3 mt-0.5 text-primary shrink-0" />
                {tip}
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <p className="text-xs font-semibold text-foreground mb-3">Ejemplos de prompts</p>
          <div className="flex flex-col gap-2">
            {[
              'Un gato negro sentado, vista de frente, ojos verdes brillantes, 16x16',
              'Espada de fuego magica, vista lateral, tonos rojos y naranja',
              'Astronauta flotando en el espacio, estilo SNES, colores suaves',
              'Cogote de champiñon con cara feliz, estilo super mario',
            ].map((ex) => (
              <div key={ex} className="code-block text-[11px]">{ex}</div>
            ))}
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'api',
    label: 'API Reference',
    content: (
      <div className="flex flex-col gap-4">
        <h2 className="text-lg font-semibold text-foreground">API Reference</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">
          ASTRILIA IA expone endpoints internos que puedes consultar directamente.
        </p>

        <div className="rounded-lg border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Badge className="text-[10px] bg-primary text-primary-foreground h-5">POST</Badge>
            <code className="text-xs font-mono text-foreground">/api/generate-pixel</code>
          </div>
          <p className="text-xs text-muted-foreground mb-3">Genera un array de pixeles a partir de un prompt de texto.</p>
          <p className="text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wider">Body</p>
          <div className="code-block text-[11px]">{`{
  "prompt": "Un dragon de fuego pequeno",
  "gridSize": 16,
  "palette": ["#000000", "#ff0000", ...]
}`}</div>
          <p className="text-xs font-semibold text-muted-foreground mt-3 mb-1.5 uppercase tracking-wider">Response</p>
          <div className="code-block text-[11px]">{`{
  "pixels": ["#000000", "transparent", "#ff0000", ...],
  "description": "Dragon rojo de fuego",
  "gridSize": 16
}`}</div>
        </div>

        <div className="rounded-lg border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Badge className="text-[10px] bg-primary text-primary-foreground h-5">POST</Badge>
            <code className="text-xs font-mono text-foreground">/api/chat</code>
          </div>
          <p className="text-xs text-muted-foreground mb-3">Chat en streaming con el asistente PIXEL. Compatible con AI SDK.</p>
          <div className="code-block text-[11px]">{`{
  "messages": [
    { "role": "user", "content": "Como hago dithering?" }
  ]
}`}</div>
        </div>
      </div>
    ),
  },
  {
    id: 'shortcuts',
    label: 'Atajos',
    content: (
      <div className="flex flex-col gap-4">
        <h2 className="text-lg font-semibold text-foreground">Atajos de teclado</h2>
        <div className="rounded-lg border border-border bg-card overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border bg-secondary/30">
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium uppercase tracking-wider text-[10px]">Atajo</th>
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium uppercase tracking-wider text-[10px]">Accion</th>
              </tr>
            </thead>
            <tbody>
              {[
                ['Ctrl + Z', 'Deshacer ultimo trazo'],
                ['Ctrl + Enter', 'Generar con IA (en el panel IA)'],
                ['Enter', 'Enviar mensaje al Bot IA'],
                ['Click + Arrastrar', 'Dibujar varios pixeles'],
              ].map(([key, action]) => (
                <tr key={key} className="border-b border-border/50 last:border-0">
                  <td className="px-4 py-2.5">
                    <kbd className="font-mono text-[10px] bg-secondary border border-border px-1.5 py-0.5 rounded text-foreground">
                      {key}
                    </kbd>
                  </td>
                  <td className="px-4 py-2.5 text-muted-foreground">{action}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    ),
  },
]

export default function DocsPage() {
  const [active, setActive] = useState('intro')
  const section = SECTIONS.find((s) => s.id === active)

  return (
    <div className="h-full flex overflow-hidden bg-background">
      {/* Docs sidebar */}
      <nav className="w-52 border-r border-border flex flex-col gap-0.5 px-3 pt-4 shrink-0 bg-[#0c0c20]">
        <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-2">
          Contenido
        </p>
        {SECTIONS.map((s) => (
          <button
            key={s.id}
            onClick={() => setActive(s.id)}
            className={`nav-item ${active === s.id ? 'active' : ''}`}
          >
            {s.label}
          </button>
        ))}
      </nav>

      {/* Content */}
      <ScrollArea className="flex-1">
        <div className="max-w-2xl mx-auto px-8 py-8">
          {section?.content}
        </div>
      </ScrollArea>
    </div>
  )
}
