'use client'

import { useEffect, useRef, useState } from 'react'
import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Bot, Send, RotateCcw, Loader2, User } from 'lucide-react'

const SUGGESTIONS = [
  'Como hago dithering en pixel art?',
  'Dame un prompt para generar un dragon',
  'Que paleta usar para un juego de terror?',
  'Como animar un personaje en 4 frames?',
  'Diferencia entre 16x16 y 32x32 para sprites',
  'Tips para hacer isometrico pixel art',
]

function getApiKey() {
  if (typeof window === 'undefined') return undefined
  return localStorage.getItem('astrilia_openai_key') || undefined
}

export default function BotPage() {
  const [apiKey] = useState<string | undefined>(getApiKey)
  const bottomRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const { messages, sendMessage, status, setMessages } = useChat({
    transport: new DefaultChatTransport({
      api: '/api/chat',
      body: { apiKey },
    }),
  })

  const [input, setInput] = useState('')

  const isLoading = status === 'submitted' || status === 'streaming'

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSend = () => {
    const text = input.trim()
    if (!text || isLoading) return
    setInput('')
    sendMessage({ text })
  }

  const handleSuggestion = (s: string) => {
    setInput(s)
    inputRef.current?.focus()
  }

  const handleReset = () => {
    setMessages([])
    setInput('')
  }

  const getText = (msg: (typeof messages)[0]) => {
    if (!msg.parts) return ''
    return msg.parts
      .filter((p): p is { type: 'text'; text: string } => p.type === 'text')
      .map((p) => p.text)
      .join('')
  }

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Top bar */}
      <div className="h-11 border-b border-border flex items-center justify-between px-4 shrink-0 bg-[#0c0c20]/60">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center">
            <Bot className="w-3.5 h-3.5 text-primary" />
          </div>
          <span className="text-xs font-medium text-foreground">PIXEL — Asistente de Pixel Art</span>
          {isLoading && <Loader2 className="w-3 h-3 text-primary animate-spin" />}
        </div>
        <Button
          size="sm"
          variant="ghost"
          onClick={handleReset}
          className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground"
        >
          <RotateCcw className="w-3 h-3" />
          Nueva sesion
        </Button>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1">
        <div className="max-w-3xl mx-auto px-4 py-6 flex flex-col gap-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 gap-6">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                <Bot className="w-7 h-7 text-primary" />
              </div>
              <div className="text-center">
                <h2 className="text-sm font-semibold text-foreground mb-1">Hola, soy PIXEL</h2>
                <p className="text-xs text-muted-foreground max-w-sm leading-relaxed">
                  Tu asistente especializado en pixel art. Preguntame sobre tecnicas, paletas, prompts para la IA o como usar ASTRILIA.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 w-full max-w-md">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => handleSuggestion(s)}
                    className="text-left px-3 py-2.5 rounded-lg border border-border bg-card hover:border-primary/40 hover:bg-primary/5 transition-all text-xs text-muted-foreground hover:text-foreground"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg) => {
              const text = getText(msg)
              const isUser = msg.role === 'user'
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                      isUser
                        ? 'bg-primary/20 border border-primary/30'
                        : 'bg-[#161632] border border-border'
                    }`}
                  >
                    {isUser ? (
                      <User className="w-3.5 h-3.5 text-primary" />
                    ) : (
                      <Bot className="w-3.5 h-3.5 text-muted-foreground" />
                    )}
                  </div>
                  <div
                    className={`max-w-[80%] px-4 py-3 rounded-xl text-xs leading-relaxed ${
                      isUser
                        ? 'chat-user text-foreground'
                        : 'chat-ai text-foreground'
                    }`}
                    style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}
                  >
                    {text}
                  </div>
                </div>
              )
            })
          )}
          {isLoading && messages[messages.length - 1]?.role === 'user' && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 bg-[#161632] border border-border">
                <Bot className="w-3.5 h-3.5 text-muted-foreground" />
              </div>
              <div className="chat-ai px-4 py-3 rounded-xl">
                <div className="flex gap-1 items-center">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce [animation-delay:0ms]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce [animation-delay:150ms]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce [animation-delay:300ms]" />
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="border-t border-border p-4 shrink-0 bg-[#0c0c20]/60">
        <div className="max-w-3xl mx-auto flex gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                handleSend()
              }
            }}
            placeholder="Pregunta algo sobre pixel art..."
            className="flex-1 bg-card border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 focus:ring-1 focus:ring-primary/20"
            disabled={isLoading}
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            size="sm"
            className="h-9 w-9 p-0 bg-primary text-primary-foreground hover:bg-primary/90 shrink-0"
          >
            {isLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground/50 text-center mt-2">
          Enter para enviar · Usa una API Key propia en Ajustes para mayor velocidad
        </p>
      </div>
    </div>
  )
}
