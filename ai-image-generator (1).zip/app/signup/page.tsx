'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Eye, EyeOff, Loader2 } from 'lucide-react'

export default function SignupPage() {
  const router = useRouter()
  const { signup } = useAuth()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    const res = await signup(name, email, password)
    setLoading(false)
    if (res.error) {
      setError(res.error)
    } else {
      router.push('/app/editor')
    }
  }

  return (
    <div className="min-h-dvh flex flex-col items-center justify-center bg-background px-4">
      <div className="fixed inset-0 canvas-bg opacity-40 pointer-events-none" />

      <div className="relative z-10 w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 mb-4 relative">
            <Image src="/logo.png" alt="ASTRILIA IA" fill className="object-contain invert" />
          </div>
          <h1
            className="text-xl font-bold tracking-widest text-foreground"
            style={{ fontFamily: 'var(--font-pixel)' }}
          >
            ASTRILIA
          </h1>
          <span className="text-xs text-muted-foreground mt-1 font-mono tracking-widest">IA PIXEL STUDIO</span>
        </div>

        <div className="auth-card p-8">
          <h2 className="text-base font-semibold text-foreground mb-1">Crear cuenta</h2>
          <p className="text-xs text-muted-foreground mb-6">Empieza a crear pixel art con IA gratis.</p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="name" className="text-xs text-muted-foreground">
                Nombre completo
              </Label>
              <Input
                id="name"
                type="text"
                placeholder="Tu Nombre"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-background border-border text-foreground placeholder:text-muted-foreground text-sm h-9 focus-visible:ring-primary/30 focus-visible:border-primary/60"
                autoComplete="name"
                required
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="email" className="text-xs text-muted-foreground">
                Correo electronico
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="tu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-background border-border text-foreground placeholder:text-muted-foreground text-sm h-9 focus-visible:ring-primary/30 focus-visible:border-primary/60"
                autoComplete="email"
                required
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="password" className="text-xs text-muted-foreground">
                Contrasena
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPass ? 'text' : 'password'}
                  placeholder="Min. 6 caracteres"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-background border-border text-foreground placeholder:text-muted-foreground text-sm h-9 pr-10 focus-visible:ring-primary/30 focus-visible:border-primary/60"
                  autoComplete="new-password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  tabIndex={-1}
                >
                  {showPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {error && (
              <p className="text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">
                {error}
              </p>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-9 bg-primary text-primary-foreground hover:bg-primary/90 text-sm font-medium mt-1"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Crear cuenta'}
            </Button>
          </form>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-5">
          Ya tienes cuenta?{' '}
          <Link href="/login" className="text-primary hover:text-primary/80 transition-colors font-medium">
            Iniciar sesion
          </Link>
        </p>
      </div>
    </div>
  )
}
