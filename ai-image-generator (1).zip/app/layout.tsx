import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono, Press_Start_2P } from 'next/font/google'
import './globals.css'

const geistSans = Geist({ variable: '--font-geist-sans', subsets: ['latin'] })
const geistMono = Geist_Mono({ variable: '--font-geist-mono', subsets: ['latin'] })
const pressStart2P = Press_Start_2P({ weight: '400', subsets: ['latin'], variable: '--font-press-start' })

export const metadata: Metadata = {
  title: 'ASTRILIA IA — Crea Pixel Art con Inteligencia Artificial',
  description: 'Editor de pixel art 2D con IA. Genera, edita y descarga sprites pixel art usando inteligencia artificial.',
  generator: 'v0.app',
  metadataBase: new URL('https://astrilia-ia.vercel.app'),
  openGraph: {
    title: 'ASTRILIA IA — Pixel Art con Inteligencia Artificial',
    description: 'Editor de pixel art 2D con IA. Genera, edita y descarga sprites usando inteligencia artificial.',
    url: 'https://astrilia-ia.vercel.app',
    siteName: 'ASTRILIA IA',
    images: [{ url: '/logo.png', width: 762, height: 1080, alt: 'ASTRILIA IA Logo' }],
    locale: 'es_ES',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ASTRILIA IA — Pixel Art con Inteligencia Artificial',
    description: 'Editor de pixel art 2D con IA.',
    images: ['/logo.png'],
  },
  icons: {
    icon: '/logo.png',
    apple: '/logo.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0a0a14',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="es"
      className={`${geistSans.variable} ${geistMono.variable} ${pressStart2P.variable} bg-background`}
    >
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
