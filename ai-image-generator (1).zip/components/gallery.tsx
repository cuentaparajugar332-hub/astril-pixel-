'use client'

import { useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'

export interface GalleryItem {
  id: string
  pixels: string[]
  gridSize: number
  prompt: string
  createdAt: number
}

interface GalleryProps {
  items: GalleryItem[]
  onLoad: (item: GalleryItem) => void
  onDelete: (id: string) => void
}

function MiniCanvas({ pixels, gridSize }: { pixels: string[]; gridSize: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const SIZE = 80

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    ctx.clearRect(0, 0, SIZE, SIZE)
    const cellSize = SIZE / gridSize
    for (let i = 0; i < gridSize * gridSize; i++) {
      const color = pixels[i]
      if (color && color !== 'transparent') {
        ctx.fillStyle = color
        ctx.fillRect((i % gridSize) * cellSize, Math.floor(i / gridSize) * cellSize, cellSize, cellSize)
      }
    }
  }, [pixels, gridSize])

  return (
    <canvas
      ref={canvasRef}
      width={SIZE}
      height={SIZE}
      style={{ imageRendering: 'pixelated', width: SIZE, height: SIZE }}
      className="block border border-border"
    />
  )
}

export function Gallery({ items, onLoad, onDelete }: GalleryProps) {
  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center font-body">
        <div className="text-4xl mb-3 font-pixel text-muted-foreground/20 text-[18px]">[ ]</div>
        <p className="text-muted-foreground text-xs">No hay creaciones guardadas aun.</p>
        <p className="text-muted-foreground/60 text-[10px] mt-1">
          Dibuja algo y haz clic en &quot;Guardar&quot; para verlo aqui.
        </p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 font-body">
      {items.map((item) => (
        <div
          key={item.id}
          className="border border-border bg-card hover:border-primary/50 transition-colors group"
        >
          <div className="p-2 flex items-center justify-center bg-muted/20">
            <MiniCanvas pixels={item.pixels} gridSize={item.gridSize} />
          </div>
          <div className="p-2">
            <p className="text-[10px] text-foreground truncate leading-tight" title={item.prompt}>
              {item.prompt || 'Sin titulo'}
            </p>
            <p className="text-[9px] text-muted-foreground mt-0.5">
              {item.gridSize}x{item.gridSize} &middot; {new Date(item.createdAt).toLocaleDateString('es')}
            </p>
            <div className="flex gap-1 mt-2">
              <Button
                size="sm"
                variant="outline"
                className="flex-1 h-6 text-[9px]"
                onClick={() => onLoad(item)}
              >
                Cargar
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="flex-1 h-6 text-[9px] hover:border-destructive hover:text-destructive"
                onClick={() => onDelete(item.id)}
              >
                Borrar
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
