'use client'

import { useRef, useEffect, useCallback, useState } from 'react'

interface PixelCanvasProps {
  pixels: string[]
  gridSize: number
  activeColor: string
  tool: 'draw' | 'erase' | 'fill'
  onPixelsChange: (pixels: string[]) => void
}

export function PixelCanvas({ pixels, gridSize, activeColor, tool, onPixelsChange }: PixelCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const isDrawingRef = useRef(false)
  const lastCellRef = useRef<number>(-1)
  const [canvasSize, setCanvasSize] = useState(512)

  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect()
        const size = Math.min(rect.width, rect.height, 600)
        setCanvasSize(size > 0 ? size : 512)
      }
    }
    updateSize()
    const ro = new ResizeObserver(updateSize)
    if (containerRef.current) ro.observe(containerRef.current)
    return () => ro.disconnect()
  }, [])

  const cellSize = canvasSize / gridSize

  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    ctx.clearRect(0, 0, canvasSize, canvasSize)

    // Dark background for transparent pixels
    ctx.fillStyle = '#111122'
    ctx.fillRect(0, 0, canvasSize, canvasSize)

    for (let i = 0; i < gridSize * gridSize; i++) {
      const x = (i % gridSize) * cellSize
      const y = Math.floor(i / gridSize) * cellSize
      if (pixels[i] && pixels[i] !== 'transparent') {
        ctx.fillStyle = pixels[i]
        ctx.fillRect(x, y, cellSize, cellSize)
      }
    }

    // Draw grid
    ctx.strokeStyle = '#1e2040'
    ctx.lineWidth = 0.5
    for (let i = 0; i <= gridSize; i++) {
      ctx.beginPath()
      ctx.moveTo(i * cellSize, 0)
      ctx.lineTo(i * cellSize, canvasSize)
      ctx.stroke()
      ctx.beginPath()
      ctx.moveTo(0, i * cellSize)
      ctx.lineTo(canvasSize, i * cellSize)
      ctx.stroke()
    }
  }, [pixels, gridSize, cellSize, canvasSize])

  useEffect(() => {
    drawCanvas()
  }, [drawCanvas])

  const getCellIndex = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
      const canvas = canvasRef.current
      if (!canvas) return -1
      const rect = canvas.getBoundingClientRect()
      let clientX: number, clientY: number
      if ('touches' in e) {
        clientX = e.touches[0].clientX
        clientY = e.touches[0].clientY
      } else {
        clientX = e.clientX
        clientY = e.clientY
      }
      const scaleX = canvasSize / rect.width
      const scaleY = canvasSize / rect.height
      const x = (clientX - rect.left) * scaleX
      const y = (clientY - rect.top) * scaleY
      const col = Math.floor(x / cellSize)
      const row = Math.floor(y / cellSize)
      if (col < 0 || col >= gridSize || row < 0 || row >= gridSize) return -1
      return row * gridSize + col
    },
    [cellSize, gridSize, canvasSize]
  )

  const floodFill = useCallback(
    (startIndex: number, targetColor: string, fillColor: string, currentPixels: string[]) => {
      if (targetColor === fillColor) return currentPixels
      const newPixels = [...currentPixels]
      const stack = [startIndex]
      const visited = new Set<number>()

      while (stack.length > 0) {
        const idx = stack.pop()!
        if (visited.has(idx) || idx < 0 || idx >= gridSize * gridSize) continue
        if ((newPixels[idx] || 'transparent') !== targetColor) continue
        visited.add(idx)
        newPixels[idx] = fillColor
        const row = Math.floor(idx / gridSize)
        const col = idx % gridSize
        if (col > 0) stack.push(idx - 1)
        if (col < gridSize - 1) stack.push(idx + 1)
        if (row > 0) stack.push(idx - gridSize)
        if (row < gridSize - 1) stack.push(idx + gridSize)
      }
      return newPixels
    },
    [gridSize]
  )

  const paintCell = useCallback(
    (index: number, currentPixels: string[]) => {
      if (index < 0) return currentPixels
      const newPixels = [...currentPixels]
      if (tool === 'draw') {
        newPixels[index] = activeColor
      } else if (tool === 'erase') {
        newPixels[index] = 'transparent'
      } else if (tool === 'fill') {
        const targetColor = newPixels[index] || 'transparent'
        return floodFill(index, targetColor, activeColor, newPixels)
      }
      return newPixels
    },
    [tool, activeColor, floodFill]
  )

  const handleMouseDown = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement>) => {
      isDrawingRef.current = true
      const idx = getCellIndex(e)
      if (idx >= 0) {
        lastCellRef.current = idx
        onPixelsChange(paintCell(idx, pixels))
      }
    },
    [getCellIndex, paintCell, pixels, onPixelsChange]
  )

  const handleMouseMove = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement>) => {
      if (!isDrawingRef.current || tool === 'fill') return
      const idx = getCellIndex(e)
      if (idx >= 0 && idx !== lastCellRef.current) {
        lastCellRef.current = idx
        onPixelsChange(paintCell(idx, pixels))
      }
    },
    [getCellIndex, paintCell, pixels, onPixelsChange, tool]
  )

  const handleMouseUp = useCallback(() => {
    isDrawingRef.current = false
    lastCellRef.current = -1
  }, [])

  const handleTouchStart = useCallback(
    (e: React.TouchEvent<HTMLCanvasElement>) => {
      e.preventDefault()
      isDrawingRef.current = true
      const idx = getCellIndex(e)
      if (idx >= 0) {
        lastCellRef.current = idx
        onPixelsChange(paintCell(idx, pixels))
      }
    },
    [getCellIndex, paintCell, pixels, onPixelsChange]
  )

  const handleTouchMove = useCallback(
    (e: React.TouchEvent<HTMLCanvasElement>) => {
      e.preventDefault()
      if (!isDrawingRef.current || tool === 'fill') return
      const idx = getCellIndex(e)
      if (idx >= 0 && idx !== lastCellRef.current) {
        lastCellRef.current = idx
        onPixelsChange(paintCell(idx, pixels))
      }
    },
    [getCellIndex, paintCell, pixels, onPixelsChange, tool]
  )

  return (
    <div
      ref={containerRef}
      className="w-full aspect-square flex items-center justify-center"
      style={{ maxWidth: '600px', margin: '0 auto' }}
    >
      <canvas
        ref={canvasRef}
        width={canvasSize}
        height={canvasSize}
        style={{ width: canvasSize, height: canvasSize, imageRendering: 'pixelated', cursor: tool === 'fill' ? 'crosshair' : 'cell' }}
        className="border border-border block"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUp}
      />
    </div>
  )
}
