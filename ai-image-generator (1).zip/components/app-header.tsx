'use client'

import { usePathname } from 'next/navigation'

const TITLES: Record<string, { label: string; desc: string }> = {
  '/app/editor':   { label: 'Editor', desc: 'Dibuja y genera pixel art' },
  '/app/bot':      { label: 'Bot IA', desc: 'Asistente de pixel art con IA' },
  '/app/gallery':  { label: 'Galeria', desc: 'Tus creaciones guardadas' },
  '/app/docs':     { label: 'Documentacion', desc: 'Aprende a usar ASTRILIA IA' },
  '/app/api-keys': { label: 'API Keys', desc: 'Gestiona tus claves de API' },
  '/app/settings': { label: 'Ajustes', desc: 'Configuracion de tu cuenta' },
}

export function AppHeader() {
  const pathname = usePathname()
  const match = Object.entries(TITLES).find(([k]) => pathname === k || pathname.startsWith(k + '/'))
  const info = match ? match[1] : { label: 'ASTRILIA IA', desc: '' }

  return (
    <header className="h-[52px] border-b border-border bg-[#0c0c20]/80 backdrop-blur-sm flex items-center px-6 shrink-0">
      <div className="flex items-center gap-3">
        <h1 className="text-sm font-semibold text-foreground">{info.label}</h1>
        {info.desc && (
          <>
            <span className="text-border">·</span>
            <span className="text-xs text-muted-foreground">{info.desc}</span>
          </>
        )}
      </div>
    </header>
  )
}
