'use client'

import Link from 'next/link'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import {
  Pencil,
  Bot,
  Images,
  BookOpen,
  Key,
  Settings,
  LogOut,
  ChevronDown,
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useRouter } from 'next/navigation'

const NAV_ITEMS = [
  { href: '/app/editor',   label: 'Editor',    icon: Pencil },
  { href: '/app/bot',      label: 'Bot IA',    icon: Bot },
  { href: '/app/gallery',  label: 'Galeria',   icon: Images },
  { href: '/app/docs',     label: 'Docs',      icon: BookOpen },
  { href: '/app/api-keys', label: 'API Keys',  icon: Key },
  { href: '/app/settings', label: 'Ajustes',   icon: Settings },
]

export function AppSidebar() {
  const pathname = usePathname()
  const { user, logout } = useAuth()
  const router = useRouter()

  const handleLogout = () => {
    logout()
    router.push('/login')
  }

  return (
    <aside
      className="flex flex-col h-full w-[220px] shrink-0 border-r border-border bg-[#0c0c20]"
      style={{ fontFamily: 'var(--font-sans)' }}
    >
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-4 border-b border-border h-[52px] shrink-0">
        <div className="w-6 h-6 relative shrink-0">
          <Image src="/logo.png" alt="ASTRILIA IA" fill className="object-contain invert" />
        </div>
        <span
          className="text-[10px] font-bold tracking-widest text-foreground leading-none"
          style={{ fontFamily: 'var(--font-pixel)' }}
        >
          ASTRILIA
        </span>
      </div>

      {/* Nav */}
      <nav className="flex flex-col gap-0.5 px-3 pt-4 flex-1">
        <span className="text-[10px] font-semibold text-muted-foreground/60 px-2 mb-1 tracking-wider uppercase">
          Menu
        </span>
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || pathname.startsWith(href + '/')
          return (
            <Link key={href} href={href} className={`nav-item ${active ? 'active' : ''}`}>
              <Icon className="w-4 h-4 shrink-0" />
              <span>{label}</span>
            </Link>
          )
        })}
      </nav>

      {/* User */}
      <div className="px-3 pb-4 shrink-0">
        <div className="border-t border-border pt-3">
          <DropdownMenu>
            <DropdownMenuTrigger className="w-full flex items-center gap-2.5 px-2 py-2 rounded-md hover:bg-secondary transition-colors outline-none">
              <div className="w-7 h-7 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
                <span className="text-[10px] font-bold text-primary">{user?.avatar ?? '??'}</span>
              </div>
              <div className="flex-1 text-left min-w-0">
                <p className="text-xs font-medium text-foreground truncate">{user?.name ?? 'Usuario'}</p>
                <p className="text-[10px] text-muted-foreground truncate">{user?.email ?? ''}</p>
              </div>
              <ChevronDown className="w-3 h-3 text-muted-foreground shrink-0" />
            </DropdownMenuTrigger>
            <DropdownMenuContent side="top" align="start" className="w-48 bg-card border-border">
              <DropdownMenuItem
                className="text-xs text-muted-foreground cursor-default"
              >
                {user?.email}
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-border" />
              <DropdownMenuItem
                onClick={() => router.push('/app/settings')}
                className="text-xs cursor-pointer gap-2"
              >
                <Settings className="w-3.5 h-3.5" /> Ajustes
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={handleLogout}
                className="text-xs cursor-pointer gap-2 text-destructive focus:text-destructive"
              >
                <LogOut className="w-3.5 h-3.5" /> Cerrar sesion
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </aside>
  )
}
