'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'

interface AIPanelProps {
  gridSize: number
  palette: string[]
  onPixelsGenerated: (pixels: string[], description: string) => void
}

const SUGGESTIONS = [
  'Un gato sentado mirando la luna',
  'Una espada de fuego magica',
  'Un dragon volando sobre montanas',
  'Un astronauta flotando en el espacio',
  'Un cogote de champiñon con ojos',
  'Una casa encantada de noche',
  'Un pez en un acuario colorido',
  'Un robot cuadrado sonriente',
]

export function AIPanel({ gridSize, palette, onPixelsGenerated }: AIPanelProps) {
  const [prompt, setPrompt] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [lastDescription, setLastDescription] = useState<string | null>(null)
  const [dots, setDots] = useState('')

  const handleGenerate = async () => {
    if (!prompt.trim()) return
    setIsLoading(true)
    setError(null)
    setLastDescription(null)

    // Animate dots
    let count = 0
    const interval = setInterval(() => {
      count = (count + 1) % 4
      setDots('.'.repeat(count))
    }, 400)

    try {
      const apiKey = typeof window !== 'undefined' ? (localStorage.getItem('astrilia_openai_key') || undefined) : undefined
      const res = await fetch('/api/generate-pixel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: prompt.trim(), gridSize, palette, apiKey }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Error desconocido')
        return
      }

      onPixelsGenerated(data.pixels, data.description)
      setLastDescription(data.description)
    } catch {
      setError('Error de red. Verifica tu conexion.')
    } finally {
      clearInterval(interval)
      setIsLoading(false)
      setDots('')
    }
  }

  const handleSuggestion = (s: string) => {
    setPrompt(s)
  }

  return (
    <div className="flex flex-col gap-4 font-body text-xs">
      <div className="border border-primary/30 p-3 bg-primary/5">
        <p className="font-pixel text-[8px] text-primary mb-1">IA GENERADOR</p>
        <p className="text-muted-foreground text-[10px] leading-relaxed">
          Describe lo que quieres crear y la IA generara el pixel art directamente en el lienzo.
        </p>
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-muted-foreground uppercase tracking-wider text-[10px]">
          Descripcion
        </label>
        <Textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="ej: Un dragon pequeño rojo con alas..."
          className="font-body text-xs resize-none h-20 bg-card border-border focus-visible:ring-0 focus-visible:border-primary text-foreground placeholder:text-muted-foreground rounded-none"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && e.ctrlKey) handleGenerate()
          }}
          disabled={isLoading}
        />
        <p className="text-[10px] text-muted-foreground">Ctrl+Enter para generar</p>
      </div>

      <Button
        onClick={handleGenerate}
        disabled={isLoading || !prompt.trim()}
        className="w-full font-body text-[11px] h-9 bg-primary text-primary-foreground hover:bg-primary/80"
      >
        {isLoading ? (
          <span>Generando{dots}</span>
        ) : (
          'Generar con IA'
        )}
      </Button>

      {error && (
        <div className="border border-destructive/50 bg-destructive/10 p-2 text-destructive text-[10px]">
          {error}
        </div>
      )}

      {lastDescription && !isLoading && (
        <div className="border border-primary/30 bg-primary/5 p-2 text-[10px] text-primary/80">
          <span className="text-muted-foreground">Generado: </span>{lastDescription}
        </div>
      )}

      <div>
        <p className="text-muted-foreground uppercase tracking-wider text-[10px] mb-2">Sugerencias</p>
        <div className="flex flex-wrap gap-1">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => handleSuggestion(s)}
              className="px-2 py-1 border border-border text-[9px] text-muted-foreground hover:border-primary hover:text-primary transition-colors font-body"
              disabled={isLoading}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="text-[9px] text-muted-foreground/60 border-t border-border pt-3">
        <p>Grid: {gridSize}x{gridSize} px | Paleta: {palette.length} colores</p>
      </div>
    </div>
  )
}
