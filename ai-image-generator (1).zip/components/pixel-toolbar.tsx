'use client'

import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { cn } from '@/lib/utils'

const PALETTE_PRESETS = {
  retro: [
    '#000000', '#ffffff', '#ff0000', '#00ff00', '#0000ff',
    '#ffff00', '#ff00ff', '#00ffff', '#ff8800', '#8800ff',
    '#00ff88', '#ff0088', '#888888', '#444444', '#cccccc',
    '#ff4444', '#44ff44', '#4444ff', '#ffaa44', '#44aaff',
  ],
  gameboy: [
    '#0f380f', '#306230', '#8bac0f', '#9bbc0f',
    '#1a1c2c', '#5d275d', '#b13e53', '#ef7d57',
    '#ffcd75', '#a7f070', '#38b764', '#257179',
    '#29366f', '#3b5dc9', '#41a6f6', '#73eff7',
  ],
  neon: [
    '#000000', '#ffffff', '#ff073a', '#fe019a',
    '#bc13fe', '#5500ff', '#0ff', '#0aefff',
    '#00ff00', '#cfff04', '#ff6600', '#ff0000',
    '#111111', '#222222', '#333333', '#555555',
  ],
} as const

type PaletteKey = keyof typeof PALETTE_PRESETS

interface PixelToolbarProps {
  tool: 'draw' | 'erase' | 'fill'
  onToolChange: (tool: 'draw' | 'erase' | 'fill') => void
  activeColor: string
  onColorChange: (color: string) => void
  gridSize: number
  onGridSizeChange: (size: number) => void
  onClear: () => void
  onUndo: () => void
  canUndo: boolean
  palette: PaletteKey
  onPaletteChange: (palette: PaletteKey) => void
}

const GRID_SIZES = [8, 16, 32, 48] as const

export function PixelToolbar({
  tool,
  onToolChange,
  activeColor,
  onColorChange,
  gridSize,
  onGridSizeChange,
  onClear,
  onUndo,
  canUndo,
  palette,
  onPaletteChange,
}: PixelToolbarProps) {
  const colors = PALETTE_PRESETS[palette]

  return (
    <div className="flex flex-col gap-4 font-body text-xs">
      {/* Tools */}
      <div>
        <p className="text-muted-foreground mb-2 uppercase tracking-wider text-[10px]">Herramienta</p>
        <div className="flex gap-2">
          {(['draw', 'erase', 'fill'] as const).map((t) => (
            <Button
              key={t}
              size="sm"
              variant={tool === t ? 'default' : 'outline'}
              onClick={() => onToolChange(t)}
              className={cn('flex-1 text-[10px] h-8', tool === t && 'bg-primary text-primary-foreground')}
            >
              {t === 'draw' ? 'Dibujar' : t === 'erase' ? 'Borrar' : 'Rellenar'}
            </Button>
          ))}
        </div>
      </div>

      {/* Grid Size */}
      <div>
        <p className="text-muted-foreground mb-2 uppercase tracking-wider text-[10px]">
          Tamano: {gridSize}x{gridSize}
        </p>
        <div className="flex gap-1">
          {GRID_SIZES.map((s) => (
            <Button
              key={s}
              size="sm"
              variant={gridSize === s ? 'default' : 'outline'}
              onClick={() => onGridSizeChange(s)}
              className={cn('flex-1 text-[10px] h-7', gridSize === s && 'bg-primary text-primary-foreground')}
            >
              {s}
            </Button>
          ))}
        </div>
      </div>

      {/* Palette selection */}
      <div>
        <p className="text-muted-foreground mb-2 uppercase tracking-wider text-[10px]">Paleta</p>
        <div className="flex gap-1">
          {(Object.keys(PALETTE_PRESETS) as PaletteKey[]).map((p) => (
            <Button
              key={p}
              size="sm"
              variant={palette === p ? 'default' : 'outline'}
              onClick={() => onPaletteChange(p)}
              className={cn('flex-1 capitalize text-[10px] h-7', palette === p && 'bg-primary text-primary-foreground')}
            >
              {p === 'retro' ? 'Retro' : p === 'gameboy' ? 'GameBoy' : 'Neon'}
            </Button>
          ))}
        </div>
      </div>

      {/* Color palette */}
      <div>
        <p className="text-muted-foreground mb-2 uppercase tracking-wider text-[10px]">
          Color: <span style={{ color: activeColor }}>{activeColor}</span>
        </p>
        <div className="grid grid-cols-10 gap-0.5">
          {colors.map((color) => (
            <button
              key={color}
              onClick={() => onColorChange(color)}
              title={color}
              style={{ backgroundColor: color }}
              className={cn(
                'w-full aspect-square border',
                activeColor === color
                  ? 'border-primary scale-110 shadow-lg shadow-primary/40 z-10 relative'
                  : 'border-border hover:border-primary/60'
              )}
            />
          ))}
        </div>

        {/* Custom color */}
        <div className="flex items-center gap-2 mt-2">
          <label className="text-muted-foreground text-[10px] uppercase tracking-wider whitespace-nowrap">
            Personalizado:
          </label>
          <input
            type="color"
            value={activeColor}
            onChange={(e) => onColorChange(e.target.value)}
            className="w-8 h-6 cursor-pointer border border-border bg-transparent rounded-none"
          />
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <Button
          size="sm"
          variant="outline"
          onClick={onUndo}
          disabled={!canUndo}
          className="flex-1 text-[10px] h-8"
        >
          Deshacer
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={onClear}
          className="flex-1 text-[10px] h-8 hover:border-destructive hover:text-destructive"
        >
          Limpiar
        </Button>
      </div>
    </div>
  )
}

export { PALETTE_PRESETS }
export type { PaletteKey }
