'use client'

import { createContext, useContext, useEffect, useState, ReactNode } from 'react'

export interface User {
  id: string
  name: string
  email: string
  avatar: string
}

interface AuthContextValue {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<{ error?: string }>
  signup: (name: string, email: string, password: string) => Promise<{ error?: string }>
  logout: () => void
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const stored = localStorage.getItem('astrilia_user')
    if (stored) {
      try {
        setUser(JSON.parse(stored))
      } catch {
        localStorage.removeItem('astrilia_user')
      }
    }
    setLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<{ error?: string }> => {
    if (!email || !password) return { error: 'Completa todos los campos.' }
    const stored = localStorage.getItem(`astrilia_account_${email}`)
    if (!stored) return { error: 'No existe una cuenta con ese email.' }
    const account = JSON.parse(stored)
    if (account.password !== password) return { error: 'Contraseña incorrecta.' }
    const u: User = { id: account.id, name: account.name, email: account.email, avatar: account.avatar }
    setUser(u)
    localStorage.setItem('astrilia_user', JSON.stringify(u))
    return {}
  }

  const signup = async (name: string, email: string, password: string): Promise<{ error?: string }> => {
    if (!name || !email || !password) return { error: 'Completa todos los campos.' }
    if (password.length < 6) return { error: 'La contraseña debe tener al menos 6 caracteres.' }
    if (localStorage.getItem(`astrilia_account_${email}`)) return { error: 'Ya existe una cuenta con ese email.' }
    const initials = name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
    const account = {
      id: crypto.randomUUID(),
      name,
      email,
      password,
      avatar: initials,
    }
    localStorage.setItem(`astrilia_account_${email}`, JSON.stringify(account))
    const u: User = { id: account.id, name: account.name, email: account.email, avatar: account.avatar }
    setUser(u)
    localStorage.setItem('astrilia_user', JSON.stringify(u))
    return {}
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('astrilia_user')
  }

  return <AuthContext.Provider value={{ user, loading, login, signup, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
